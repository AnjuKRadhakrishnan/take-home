package TakeHomeChallenge.services;

import io.restassured.RestAssured;
import io.restassured.builder.RequestSpecBuilder;
import io.restassured.filter.log.LogDetail;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.specification.RequestSpecification;
import org.apache.http.HttpStatus;
import io.restassured.module.jsv.JsonSchemaValidator;


import java.io.File;
import java.io.InputStream;

public class GameService {
    private final String baseUri="http://localhost:8080";
    private final String basePath ="/game";
    private RequestSpecification requestSpecification;

    public GameService() {
        requestSpecification= new RequestSpecBuilder()
                .log(LogDetail.ALL)
                .setBaseUri(baseUri)
                .setBasePath(basePath)
                .setContentType(ContentType.JSON)
                .build();
    }


    public String requstedGameService(String game) {
        //String name = null;
        String response= RestAssured
                .given()
                .spec(requestSpecification)
                .queryParam("name",game)
                .when()
                .get()
                .then()
                .log().all()
                .assertThat().statusCode(HttpStatus.SC_OK)
                .extract().body().asString();
        JsonPath js = new JsonPath(response);
        String text=js.getString("text");
        return text;
    }

    public String defaultGameService() {
        String response= RestAssured
                .given()
                .spec(requestSpecification)
                .when()
                .get()
                .then()
                .log().all()
                .assertThat().statusCode(HttpStatus.SC_OK)
                .extract().body().asString();
        JsonPath js = new JsonPath(response);
        String text=js.getString("text");
        return text;
    }

    public void verifyResponseJsonSchema(String game) {
        InputStream gameServiceJsonSchema=getClass().getClassLoader().getResourceAsStream("gameServiceJsonSchema.json");
        RestAssured
                .given()
                .spec(requestSpecification)
                .queryParam("name",game)
                .when()
                .get()
                .then()
                .log().all()
                .assertThat().statusCode(HttpStatus.SC_OK)
                .body(JsonSchemaValidator.matchesJsonSchema(gameServiceJsonSchema));
    }

    public int getId(String game) {
        String response= RestAssured
                .given()
                .spec(requestSpecification)
                .queryParam("name",game)
                .when()
                .get()
                .then()
                .log().all()
                .assertThat().statusCode(HttpStatus.SC_OK)
                .extract().body().asString();
        JsonPath js = new JsonPath(response);
        int id=js.getInt("id");
        return id;
    }

    public void invalidRequest() {
        RestAssured
                .given()
                .spec(requestSpecification)
                .when()
                .get("s")
                .then()
                .log().all()
                .assertThat().statusCode(HttpStatus.SC_NOT_FOUND);

    }
}
