package TakeHomeChallenge.tests;

import TakeHomeChallenge.services.GameService;
import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class GameServiceTests {
    private GameService service;

    @BeforeTest
    public void setup(){
        service = new GameService();
    }

    @Test
    public void verifyRequestedGameTest(){
        String game="chess";
        String text=service.requstedGameService(game);
        Assert.assertTrue(text.contains(game));
    }
    @Test
    public void verifyDefaultGameTest(){
        String game="Sudoku";
        String text=service.defaultGameService();
        Assert.assertTrue(text.contains(game));
    }
    @Test
    public void validateJsonSchemaTest(){
        String game="chess";
        service.verifyResponseJsonSchema(game);
    }
    @Test
    public  void verifyIdIncrementsTest(){
        String game="chess";
       int  id=service.getId(game);
       int id_new= service.getId(game);
       Assert.assertTrue(id_new>id);
    }

    @Test
    public void invalidRequestTest(){
        String game="chess";
        service.invalidRequest();

    }

}
